/*
 * Copyright (c) 2007-2009 The Khronos Group Inc.
 *
 * Permission is hereby granted, free of charge, to any person obtaining
 * a copy of this software and/or associated documentation files (the
 * "Materials "), to deal in the Materials without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sublicense, and/or sell copies of the Materials, and to
 * permit persons to whom the Materials are furnished to do so, subject to
 * the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Materials.
 *
 * THE MATERIALS ARE PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
 * CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
 * TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 * MATERIALS OR THE USE OR OTHER DEALINGS IN THE MATERIALS.
 *
 * OpenMAXALDTVExtension.h - OpenMAX AL - Digital TV Extension
 *
 */

/****************************************************************************/
/* NOTE: This file is a standard OpenMAX AL DTV Extension file and should   */
/* not be modified in any way.                                              */
/****************************************************************************/

#ifndef _OPENMAXALDTVEXTENSION_H_
#define _OPENMAXALDTVEXTENSION_H_

#include <OMXAL/OpenMAXAL.h>

#ifdef __cplusplus
extern "C" {
#endif

  /*****************************************************************/
  /* GENERAL INTERFACES, STRUCTS AND DEFINES                       */
  /*****************************************************************/

/* XADTVContentProtectionItf */

  /* Macros indicating content protection status */
#define XA_DTV_CONTENT_PROTECTION_MISSING_RIGHTS ((XAuint32) 0x00000001)
#define XA_DTV_CONTENT_PROTECTION_EXPIRED_RIGHTS ((XAuint32) 0x00000002)

typedef struct XADTVContentProtectionInfo_ {
    XAchar * pUri;
    XAuint32 reason;
    XAuint32 streamIndex;
} XADTVContentProtectionInfo;

XA_API extern const XAInterfaceID XA_IID_DTVCONTENTPROTECTION;

struct XADTVContentProtectionItf_;
typedef const struct XADTVContentProtectionItf_ * const * XADTVContentProtectionItf;

typedef void (XAAPIENTRY * xaDTVContentProtectionCallback) (
    XADTVContentProtectionItf Caller,
    XADTVContentProtectionInfo * pContentProtectionInfo,
    void * pContext
);

struct XADTVContentProtectionItf_ {
    XAresult (*RegisterContentProtectionCallback) (
        XADTVContentProtectionItf self,
        xaDTVContentProtectionCallback Callback,
        void * pContext
    );
};



/* XADTVPlayerTimedObjectsItf */

  /* Used for indicating capabilities and EnableHint */
#define XA_DTV_PLAYER_TIMED_OBJECTS_TEXT     ((XAuint32) 0x00000001)
#define XA_DTV_PLAYER_TIMED_OBJECTS_GRAPHICS ((XAuint32) 0x00000002)
#define XA_DTV_PLAYER_TIMED_OBJECTS_HTML     ((XAuint32) 0x00000004)
#define XA_DTV_PLAYER_TIMED_OBJECTS_ALL      ((XAuint32) 0xFFFFFFFF)
#define XA_DTV_PLAYER_TIMED_OBJECTS_NONE     ((XAuint32) 0x00000000)

XA_API extern const XAInterfaceID XA_IID_DTVPLAYERTIMEDOBJECTS;

struct XADTVPlayerTimedObjectsItf_;
typedef const struct XADTVPlayerTimedObjectsItf_ * const * XADTVPlayerTimedObjectsItf;

typedef void (XAAPIENTRY * xaDTVTimedObjectsCallback) (
    XADTVPlayerTimedObjectsItf Caller,
    XAchar * pMimeType,
    void * pData,
    XAuint32 DataLength,
    XAmillisecond PresentationTime,
    XAuint32 PresentationDuration,
    XAuint32 PositionHintX,
    XAuint32 PositionHintY,
    void * pContext
);

struct XADTVPlayerTimedObjectsItf_ {
    XAresult (*GetCapabilities) (
        XADTVPlayerTimedObjectsItf self,
		XAuint32 * pCapabilities
    );
    XAresult (*SetEnable) (
        XADTVPlayerTimedObjectsItf self,
 		XAuint32 EnableHint
    );
    XAresult (*GetEnable) (
        XADTVPlayerTimedObjectsItf self,
 		XAuint32 * pEnableHint
    );
    XAresult (*RegisterTimedObjectsCallback) (
        XADTVPlayerTimedObjectsItf self,
        xaDTVTimedObjectsCallback Callback,
        void * pContext
    );
};



/* XADTVPlayerTimeShiftControlItf */

typedef struct XADTVServiceTimeShiftInfo_ {
    XAtime   DataStartTime;
    XAtime   DataEndTime;
    XAuint32 BufferBytesUsed;
    XAuint32 BufferBytesAvailable;
    XAuint32 BufferSecondsUsed;
    XAuint32 BufferSecondsAvailable;
} XADTVServiceTimeShiftInfo;

XA_API extern const XAInterfaceID XA_IID_DTVPLAYERTIMESHIFTCONTROL;

struct XADTVPlayerTimeShiftControlItf_;
typedef const struct XADTVPlayerTimeShiftControlItf_ * const * XADTVPlayerTimeShiftControlItf;

typedef void (XAAPIENTRY * xaDTVTimeShiftInfoCallback) (
    XADTVPlayerTimeShiftControlItf Caller,
    XADTVServiceTimeShiftInfo * pTimeShiftInfo,
    void * pContext
);

struct XADTVPlayerTimeShiftControlItf_ {
    XAresult (*SetCacheLength) (
        XADTVPlayerTimeShiftControlItf self,
        XAboolean ringBuffer,
        XAuint32 * pBufferSize
    );
    XAresult (*RegisterTimeShiftInfoCallback) (
        XADTVPlayerTimeShiftControlItf self,
        xaDTVTimeShiftInfoCallback Callback,
        XAmillisecond Period,
        void * pContext
    );
    XAresult (*GetCacheLength) (
        XADTVPlayerTimeShiftControlItf self,
        XAuint32 * pBufferSize,
        XAboolean ringBuffer
    );
    XAresult (*GetMaximumCacheLength) (
        XADTVPlayerTimeShiftControlItf self,
        XAuint32 * pMaxSize
    );
    XAresult (*SetEnabled) (
        XADTVPlayerTimeShiftControlItf self,
        XAboolean Enable
    );
    XAresult (*IsEnabled) (
        XADTVPlayerTimeShiftControlItf self,
        XAboolean * pEnabled
    );
    XAresult (*SaveAvailableData) (
        XADTVPlayerTimeShiftControlItf self,
        XAchar * pUri
    );
};



/* XADTVProgramGuidePurchaseItf */

  /* These macros are also used in other program-guide related interfaces */
#define XA_DTV_EPG_CONTENT_ID_TYPE_BUNDLE  ((XAuint32) 0x00000002)
#define XA_DTV_EPG_CONTENT_ID_TYPE_SERVICE ((XAuint32) 0x00000001)
#define XA_DTV_EPG_CONTENT_ID_TYPE_CONTENT ((XAuint32) 0x00000000)

XA_API extern const XAInterfaceID XA_IID_DTVPROGRAMGUIDEPURCHASE;

struct XADTVProgramGuidePurchaseItf_;
typedef const struct XADTVProgramGuidePurchaseItf  * const * XADTVProgramGuidePurchaseItf;

struct XADTVProgramGuidePurchaseItf_ {
    XAresult (*GetPurchaseURI) (
        XADTVProgramGuidePurchaseItf self,
        XAuint32 bearerID,
        XAuint32 IDType,
        XAuint32 ID,
        XAuint32 * pURILength,
        XAchar * pURI
    );
};



/* XADTVServiceGuideQueryItf */

  /* Macros related to the various attributes on program-guide entries */
#define XA_DTV_EPG_ATTR_INT_PERMISSION   ((XAuint32) 0x00000006)
#define XA_DTV_EPG_ATTR_INT_SERVICE_TYPE ((XAuint32) 0x00000020)

#define XA_DTV_EPG_ATTR_INT_PRICE_DECIMAL_PART ((XAuint32) 0x00000051)
#define XA_DTV_EPG_ATTR_INT_PRICE_INTEGER_PART ((XAuint32) 0x00000050)

#define XA_DTV_EPG_ATTR_STR_DESCRIPTION            ((XAuint32) 0x00000002)
#define XA_DTV_EPG_ATTR_STR_GENRE                  ((XAuint32) 0x00000003)
#define XA_DTV_EPG_ATTR_STR_NAME                   ((XAuint32) 0x00000001)
#define XA_DTV_EPG_ATTR_STR_PARENTAL_RATING        ((XAuint32) 0x00000004)
#define XA_DTV_EPG_ATTR_STR_PARENTAL_RATING_SYSTEM ((XAuint32) 0x00000005)
#define XA_DTV_EPG_ATTR_STR_PRICE_CURRENCY         ((XAuint32) 0x00000041)
#define XA_DTV_EPG_ATTR_STR_WEBSHOP_URL            ((XAuint32) 0x00000040)

#define XA_DTV_EPG_ATTR_TIME_END   ((XAuint32) 0x00000011)
#define XA_DTV_EPG_ATTR_TIME_START ((XAuint32) 0x00000010)

  /* Comparators used for filtering program-guide entries */
#define XA_DTV_EPG_OPR_COMP_EQUAL        ((XAuint8) 2)
#define XA_DTV_EPG_OPR_COMP_GREATER_THAN ((XAuint8) 3)
#define XA_DTV_EPG_OPR_COMP_LESS_THAN    ((XAuint8) 1)

  /* Macros defining protection-state on program-guide entries */
#define XA_DTV_EPG_PERMISSION_NOT_PROTECTED  ((XAuint32) 0x00000000)
#define XA_DTV_EPG_PERMISSION_NOT_SUBSCRIBED ((XAuint32) 0x00000001)
#define XA_DTV_EPG_PERMISSION_SUBSCRIBED     ((XAuint32) 0x00000002)

  /* Macros defining the service-type for the program-guide entries */
#define XA_DTV_SERVICE_TYPE_BASIC_RADIO		((XAuint32) 0x00000002)
#define XA_DTV_SERVICE_TYPE_BASIC_TV		((XAuint32) 0x00000001)
#define XA_DTV_SERVICE_TYPE_CACHECAST		((XAuint32) 0x00000004)
#define XA_DTV_SERVICE_TYPE_FILE_DOWNLOAD	((XAuint32) 0x00000005)
#define XA_DTV_SERVICE_TYPE_RESERVED1		((XAuint32) 0x00000003)
#define XA_DTV_SERVICE_TYPE_UNSPECIFIED		((XAuint32) 0x00000000)

  /* This type used both by the XADTVProgramGuideQueryItf and the XADTVServiceInputSelectorItf */
typedef struct XADTVServiceConnectionInfo_ {
    XAchar   serviceName[256];
    XAuint32 IDType;
    XAuint32 ID;
    void *   pConnectionData;
} XADTVServiceConnectionInfo;

XA_API extern const XAInterfaceID XA_IID_DTVPROGRAMGUIDEQUERY;

struct XADTVProgramGuideQueryItf_;
typedef const struct XADTVProgramGuideQueryItf  * const * XADTVProgramGuideQueryItf;

struct XADTVProgramGuideQueryItf_ {
    XAresult (*ANDServiceFilterString) (
        XADTVProgramGuideQueryItf self,
        XAuint32 stringAttribute,
        XAchar * pStringValue
    );
    XAresult (*ANDServiceFilterInt) (
        XADTVProgramGuideQueryItf self,
        XAuint32 intAttribute,
        XAuint32 intValue
    );
    XAresult (*ANDContentFilterString) (
        XADTVProgramGuideQueryItf self,
        XAuint32 stringAttribute,
        XAchar * pStringValue
    );
    XAresult (*ANDContentFilterTime) (
        XADTVProgramGuideQueryItf self,
        XAuint32 timeAttribute,
        XAtime timeValue,
        XAuint8 operation
    );
    XAresult (*ResetServiceFilterString) (
        XADTVProgramGuideQueryItf self,
        XAuint32 stringAttribute
    );
    XAresult (*ResetServiceFilterInt) (
        XADTVProgramGuideQueryItf self,
        XAuint32 intAttribute
    );
    XAresult (*ResetContentFilterString) (
        XADTVProgramGuideQueryItf self,
        XAuint32 stringAttribute
    );
    XAresult (*ResetContentFilterTime) (
        XADTVProgramGuideQueryItf self,
        XAuint32 timeAttribute
    );
    XAresult (*GetServices) (
        XADTVProgramGuideQueryItf self,
        XAuint32 * pNumberOfServices,
        XAuint32 * pServices
    );
    XAresult (*GetServiceStringAttrib) (
        XADTVProgramGuideQueryItf self,
        XAuint32 serviceID,
        XAuint32 stringAttribute,
        XAuint32 * pStringLength,
        XAchar * pStringValue
    );
    XAresult (*GetServiceIntAttrib) (
        XADTVProgramGuideQueryItf self,
        XAuint32 serviceID,
        XAuint32 intAttribute,
        XAuint32 * pValue
    );
    XAresult (*GetContents) (
        XADTVProgramGuideQueryItf self,
        XAuint32 serviceID,
        XAuint32 * pNumberOfContents,
        XAuint32 * pContents
    );
    XAresult (*GetContentStringAttrib) (
        XADTVProgramGuideQueryItf self,
        XAuint32 contentID,
        XAuint32 stringAttribute,
        XAuint32 * pStringLength,
        XAchar * pStringValue
    );
    XAresult (*GetContentIntAttrib) (
        XADTVProgramGuideQueryItf self,
        XAuint32 contentID,
        XAuint32 intAttribute,
        XAuint32 * pIntValue
    );
    XAresult (*GetContentTimeAttrib) (
        XADTVProgramGuideQueryItf self,
        XAuint32 contentID,
        XAuint32 timeAttribute,
        XAtime * pTimeValue
    );
    XAresult (*GetPurchaseBundlesOfService) (
        XADTVProgramGuideQueryItf self,
        XAuint32 serviceID,
        XAuint32 * pNumberOfBundles,
        XAuint32 * pBundles
    );
    XAresult (*GetPurchaseBundlesOfContent) (
        XADTVProgramGuideQueryItf self,
        XAuint32 contentID,
        XAuint32 * pNumberOfBundles,
        XAuint32 * pBundles
    );
    XAresult (*GetAllPurchaseBundles) (
        XADTVProgramGuideQueryItf self,
        XAuint32 * pNumberOfBundles,
        XAuint32 * pBundles
    );
    XAresult (*GetServicesOfPurchaseBundle) (
        XADTVProgramGuideQueryItf self,
        XAuint32 bundleID,
        XAuint32 * pNumberOfServices,
        XAuint32 * pServices
    );
    XAresult (*GetContentsOfPurchaseBundle) (
        XADTVProgramGuideQueryItf self,
        XAuint32 bundleID,
        XAuint32 * pNumberOfContents,
        XAuint32 * pContents
    );
    XAresult (*GetSubscribedPurchaseBundles) (
        XADTVProgramGuideQueryItf self,
        XAuint32 * pNumberOfBundles,
        XAuint32 * pBundles
    );
    XAresult (*GetBundleStringAttrib) (
        XADTVProgramGuideQueryItf self,
        XAuint32 bundleID,
        XAuint32 stringAttribute,
        XAuint32 * pStringLength,
        XAchar * pStringValue
    );
    XAresult (*GetBundleIntAttrib) (
        XADTVProgramGuideQueryItf self,
        XAuint32 bundleID,
        XAuint32 intAttribute,
        XAuint32 * pValue
    );
    XAresult (*GetBundleTimeAttrib) (
        XADTVProgramGuideQueryItf self,
        XAuint32 bundleID,
        XAuint32 timeAttribute,
        XAtime * pTimeValue
    );
    XAresult (*CreateServiceConnectionInfo) (
        XADTVProgramGuideQueryItf self,
        XAuint32 IDType,
        XAuint32 ID,
        void * pInternetConnection,
        XADTVServiceConnectionInfo * pServiceConnectionInfo
    );
};



/* XADTVProgramGuideUpdateItf */

XA_API extern const XAInterfaceID XA_IID_DTVPROGRAMGUIDEUPDATE;

struct XADTVProgramGuideUpdateItf_;
typedef const struct XADTVProgramGuideUpdateItf  * const * XADTVProgramGuideUpdateItf;

typedef void (XAAPIENTRY * xaEPGUpdateCallback) (
    XADTVProgramGuideUpdateItf Caller,
    XAuint32 bearerID,
    XAchar * pEPGName,
    XAchar * pEPGData,
    void * pContext
);

typedef void (XAAPIENTRY * xaEPGGetEPGCallback) (
    XADTVProgramGuideUpdateItf Caller,
    XAuint32 bearerID,
    void * pContext
);

struct XADTVProgramGuideUpdateItf_ {
    XAresult (*EnableEPGListening) (
        XADTVProgramGuideUpdateItf self,
        XAuint32 bearerID,
        XAboolean IncludeEPGData,
        void * pContext
    );
    XAresult (*DisableEPGListening) (
        XADTVProgramGuideUpdateItf self,
        XAuint32 bearerID
    );
    XAresult (*SetEPG) (
        XADTVProgramGuideUpdateItf self,
        XAuint32 bearerID,
        XAchar * pURI
    );
    XAresult (*GetEPG) (
        XADTVProgramGuideUpdateItf self,
        XAuint32 BearerID,
        XAchar * pURI,
        void * pContext
    );
    XAresult (*IsEPGListeningEnabled) (
        XADTVProgramGuideUpdateItf self,
        XAuint32 BearerID,
        XAboolean * pIsListening
    );

    XAresult (*IsEPGStoragePersistent) (
        XADTVProgramGuideUpdateItf self,
        XAboolean * pIsPersistent
    );
    XAresult (*RegisterEPGGetEPGCallback) (
        XADTVProgramGuideUpdateItf self,
        xaEPGGetEPGCallback Callback,
        void * pContext
    );
    XAresult (*RegisterEPGUpdateCallback) (
        XADTVProgramGuideUpdateItf self,
        xaEPGUpdateCallback Callback,
        void * pContext
    );
};



/* XADTVRecorderModeItf */

#define XA_DTV_RECORDER_MODE_ALL_STREAMS_RAW ((XAuint32) 0x00000001)
#define XA_DTV_RECORDER_MODE_ACTIVE_STREAMS  ((XAuint32) 0x00000002)

XA_API extern const XAInterfaceID XA_IID_DTVRECORDERMODE;

struct XADTVRecorderModeItf_;
typedef const struct XADTVRecorderModeItf_ * const * XADTVRecorderModeItf;

struct XADTVRecorderModeItf_ {
    XAresult (*QueryRecordModeCapabilities) (
        XADTVRecorderModeItf self,
        XAuint32 * pRecordModeCapabilities
    );
    XAresult (*SetDTVRecordMode) (
        XADTVRecorderModeItf self,
        XAuint32 RecordMode
    );
    XAresult (*GetDTVRecordMode) (
        XADTVRecorderModeItf self,
        XAuint32 * pRecordMode
    );
};



/* XADTVServiceDataDeliveryItf */

  /* Macros associated with the download progress */
#define XA_DTV_SERVICE_FILE_DL_PROGRESS_DOWNLOADING ((XAuint32) 0x00000001)
#define XA_DTV_SERVICE_FILE_DL_PROGRESS_FINISHED    ((XAuint32) 0x00000002)
#define XA_DTV_SERVICE_FILE_DL_PROGRESS_ABORTED     ((XAuint32) 0x00000003)

  /* Macros defining update status for file descriptors */
#define XA_DTV_SERVICE_FILE_DESCRIPTION_NEW     ((XAuint32) 0x00000001)
#define XA_DTV_SERVICE_FILE_DESCRIPTION_UPDATED ((XAuint32) 0x00000002)
#define XA_DTV_SERVICE_FILE_DESCRIPTION_REMOVED ((XAuint32) 0x00000003)

typedef struct XADTVServiceDataDeliveryFileDescriptor_ {
    XAchar * pFileName;
    XAuint32 Version;
    XAuint32 FileLength;
    XAchar * pMIMEType;
} XADTVServiceDataDeliveryFileDescriptor;

XA_API extern const XAInterfaceID XA_IID_DTVSERVICEDATADELIVERY;

struct XADTVServiceDataDeliveryItf_;
typedef const struct XADTVServiceDataDeliveryItf_ * const * XADTVServiceDataDeliveryItf;

typedef void (XAAPIENTRY * xaServiceFileDescriptionUpdateCallback) (
    XADTVServiceDataDeliveryItf Caller,
    XAuint32 UpdateType,
    XADTVServiceDataDeliveryFileDescriptor * pFileDescriptor,
    void * pContext
);

typedef void (XAAPIENTRY * xaDTVServiceFileDownloadProgressCallback) (
    XADTVServiceDataDeliveryItf Caller,
    XAuint32  ProgressStatus,
    XApermille Progress,
    XADTVServiceDataDeliveryFileDescriptor * pFileDescriptor,
    void * pContext
);

struct XADTVServiceDataDeliveryItf_ {
    XAresult (*SetEnabled) (
   	    XADTVServiceDataDeliveryItf self,
		XAboolean Enabled
    );
    XAresult (*IsEnabled) (
        XADTVServiceDataDeliveryItf self,
		XAboolean * pIsEnabled
    );
    XAresult (*SetFileDeliveryCache) (
        XADTVServiceDataDeliveryItf self,
        XAuint32 Size,
        XAchar * pUri
    );
    XAresult (*List) (
        XADTVServiceDataDeliveryItf self,
        XAuint32 * NumberOfFiles,
        XADTVServiceDataDeliveryFileDescriptor * pFileDescriptors,
        XAboolean * pIsCached
    );
    XAresult (*Download) (
        XADTVServiceDataDeliveryItf self,
        XADTVServiceDataDeliveryFileDescriptor * pFileDescriptor,
        XAchar * pUri
    );
    XAresult (*AbortDownload) (
        XADTVServiceDataDeliveryItf self,
        XADTVServiceDataDeliveryFileDescriptor * pFileDescriptor
    );
    XAresult (*RegisterServiceFileDescriptionCallback) (
        XADTVServiceDataDeliveryItf self,
        xaServiceFileDescriptionUpdateCallback Callback,
        void * pContext
    );
    XAresult (*RegisterServiceFileDownloadProgressCallback) (
        XADTVServiceDataDeliveryItf self,
        xaDTVServiceFileDownloadProgressCallback Callback,
        void * pContext
    );
};



/* XADTVServiceInputSelectorItf */

XA_API extern const XAInterfaceID XA_IID_DTVSERVICEINPUTSELECTOR;

struct XADTVServiceInputSelectorItf_;
typedef const struct XADTVServiceInputSelectorItf_ * const * XADTVServiceInputSelectorItf;

struct XADTVServiceInputSelectorItf_ {
    XAresult (*ConnectUsingProgramGuideData) (
        XADTVServiceInputSelectorItf self,
		XADTVServiceConnectionInfo * pServiceConnectionInfo
    );
    XAresult (*ConnectUsingBearerID) (
        XADTVServiceInputSelectorItf self,
		XAuint32 bearerID
    );
    XAresult (*IsConnected) (
        XADTVServiceInputSelectorItf self,
        XAboolean * pIsConnected
    );
};



/* XADTVSourceBroadcastItf */

typedef struct XADTVSourceScanInfo_ {
    XAuint32  bearerId;
    XAchar *  pScanName;
    XAuint32  scanNameLength;
    XAboolean singleService;
    XAchar *  pMultiplexMIMEType;
    XAuint32  multiplexMIMETypeLength;
    void *    pBearerSpecificScanData;
} XADTVSourceScanInfo;

XA_API extern const XAInterfaceID XA_IID_DTVSOURCEBROADCAST;

struct XADTVSourceBroadcastItf_;
typedef const struct XADTVSourceBroadcastItf_ * const * XADTVSourceBroadcastItf;

typedef void (XAAPIENTRY * xaDTVSourceScanningCallback) (
    XADTVSourceBroadcastItf Caller,
    XAuint32 bearerID,
    XADTVSourceScanInfo * pScanInfo,
    void * pContext
);

struct XADTVSourceBroadcastItf_ {
    XAresult (*EnableScan) (
        XADTVSourceBroadcastItf self,
        XAboolean enable,
        XAuint32 bearerID,
        void * pContext
    );
    XAresult (*SetScanInfo) (
        XADTVSourceBroadcastItf self,
        XAuint32 bearerID,
        XADTVSourceScanInfo * pScanInfo
    );
    XAresult (*GetScanInfo) (
        XADTVSourceBroadcastItf self,
        XAuint32 bearerID,
        XADTVSourceScanInfo * pScanInfo
    );
    XAresult (*IsScanning) (
        XADTVSourceBroadcastItf self,
        XAuint32 bearerID,
        XAboolean * pIsScanning
    );
    XAresult (*RegisterSourceScanningCallback) (
        XADTVSourceBroadcastItf self,
        xaDTVSourceScanningCallback Callback,
        void * pContext
    );
};



/* XADTVSourceLocalItf */

typedef struct XADTVLocalAssociateInfo_ {
    XAchar uri[256];
} XADTVLocalAssociateInfo;

XA_API extern const XAInterfaceID XA_IID_DTVSOURCELOCAL;

struct XADTVSourceLocalItf_;
typedef const struct XADTVSourceLocalItf  * const * XADTVSourceLocalItf;

struct XADTVSourceLocalItf_ {
    XAresult (*Associate) (
        XADTVSourceLocalItf self,
        XADTVLocalAssociateInfo * pLocalAssociateInfo,
        XAuint32 * pBearerID
    );
    XAresult (*Disassociate) (
        XADTVSourceLocalItf self,
        XAuint32 bearerID
    );
    XAresult (*IsAssociated) (
        XADTVSourceLocalItf self,
        XAboolean * pIsAssociated
    );
};



/* XADTVSourceMulticastItf */

  /* Macros defining the multicast connection-state */
#define XA_DTV_MULTICAST_CONNECTION_STATE_CONNECTED           ((XAuint32) 0x00000001)
#define XA_DTV_MULTICAST_CONNECTION_STATE_CONNECTED_RECEIVING ((XAuint32) 0x00000002)
#define XA_DTV_MULTICAST_CONNECTION_STATE_DISCONNECTED        ((XAuint32) 0x00000003)

  /* Macros indicating the multicast technology in use */
#define XA_DTV_MULTICAST_TECHNOLOGY_IPTV ((XAuint32) 0x00000001)
#define XA_DTV_MULTICAST_TECHNOLOGY_MBMS ((XAuint32) 0x00000002)

typedef struct XADTVMulticastGroupInfo_ {
    XAuint32 technologyIdentifier;
    void *   pInternetConnection;
    XAchar   multicastGroupURL[256];
} XADTVMulticastGroupInfo;

XA_API extern const XAInterfaceID XA_IID_DTVSOURCEMULTICAST;

struct XADTVSourceMulticastItf_;
typedef const struct XADTVSourceMulticastItf  * const * XADTVSourceMulticastItf;

typedef void (XAAPIENTRY * xaDTVMulticastConnectionStateChangedCallback) (
    XADTVSourceMulticastItf Caller,
    XAuint32 bearerID,
    XAuint32 connectionState,
    void * pContext
);

 struct XADTVSourceMulticastItf_ {
    XAresult (*QuerySupportedMulticastTechnologies) (
        XADTVSourceMulticastItf self,
        XAuint32 * pNumberOfTechnologies,
        XAuint32 * pTechnologies
    );
    XAresult (*JoinMulticastGroup) (
        XADTVSourceMulticastItf self,
        XADTVMulticastGroupInfo * pMulticastGroupInfo,
        XAuint32 * pBearerID
    );
    XAresult (*LeaveMulticastGroup) (
        XADTVSourceMulticastItf self,
        XAuint32 bearerID
    );
    XAresult (*GetMulticastBearerConnectionState) (
        XADTVSourceMulticastItf self,
        XAuint32 bearerID,
        XAuint32 * pState
    );
    XAresult (*RegisterMulticastConnectionStateChangedCallback) (
        XADTVSourceMulticastItf self,
        xaDTVMulticastConnectionStateChangedCallback Callback,
        void * pContext
    );
};



/* XADTVSourceUnicastItf */

  /* Macros defining the unicast connection-state */
#define XA_DTV_UNICAST_CONNECTION_STATE_CONNECTED			((XAuint32) 0x00000001)
#define XA_DTV_UNICAST_CONNECTION_STATE_CONNECTED_RECEIVING	((XAuint32) 0x00000002)
#define XA_DTV_UNICAST_CONNECTION_STATE_DISCONNECTED		((XAuint32) 0x00000003)

  /* Macros indicating the unicast technology in use */
#define XA_DTV_UNICAST_TECHNOLOGY_RTSP ((XAuint32) 0x00000001)
#define XA_DTV_UNICAST_TECHNOLOGY_HTTP ((XAuint32) 0x00000002)

typedef struct XADTVUnicastConnectInfo_ {
    XAuint32 technologyIdentifier;
    void *   pInternetConnection;
    XAchar   unicastURL[256];
} XADTVUnicastConnectInfo;

XA_API extern const XAInterfaceID XA_IID_DTVSOURCEUNICAST;

struct XADTVSourceUnicastItf_;
typedef const struct XADTVSourceUnicastItf  * const * XADTVSourceUnicastItf;

typedef void (XAAPIENTRY * xaDTVUnicastConnectionStateChangedCallback) (
    XADTVSourceUnicastItf Caller,
    XAuint32 bearerID,
    XAuint32 connectionState,
    void * pContext
);

struct XADTVSourceUnicastItf_ {
    XAresult (*QuerySupportedUnicastTechnologies) (
        XADTVSourceUnicastItf self,
        XAuint32 * pNumberOfTechnologies,
        XAuint32 * pTechnologies
    );
    XAresult (*Connect) (
        XADTVSourceUnicastItf self,
        XADTVUnicastConnectInfo * pUnicastConnectInfo,
        XAuint32 * pBearerID
    );
    XAresult (*Disconnect) (
        XADTVSourceUnicastItf self,
        XAuint32 bearerID
    );
    XAresult (*GetUnicastBearerConnectionState) (
        XADTVSourceUnicastItf self,
        XAuint32 bearerID,
        XAuint32 * pState
    );
    XAresult (*RegisterUnicastConnectionStateChangedCallback) (
        XADTVSourceUnicastItf self,
        xaDTVUnicastConnectionStateChangedCallback Callback,
        void * pContext
    );
};



/* XADTVSourceUtilitiesItf */

  /* Macros indicating the bearer family */
#define XA_DTV_BEARER_FAMILY_DVB  ((XAuint32) 0x00000000)
#define XA_DTV_BEARER_FAMILY_ATSC ((XAuint32) 0x00000001)
#define XA_DTV_BEARER_FAMILY_ISDB ((XAuint32) 0x00000002)
#define XA_DTV_BEARER_FAMILY_IMB  ((XAuint32) 0x00000003)
#define XA_DTV_BEARER_FAMILY_DMB  ((XAuint32) 0x00000004)
#define XA_DTV_BEARER_FAMILY_CMMB ((XAuint32) 0x00000005)
#define XA_DTV_BEARER_FAMILY_MBMS ((XAuint32) 0x00000006)
#define XA_DTV_BEARER_FAMILY_RTSP ((XAuint32) 0x00000007)
#define XA_DTV_BEARER_FAMILY_HTTP ((XAuint32) 0x00000008)
#define XA_DTV_BEARER_FAMILY_FILE ((XAuint32) 0x00000009)

  /* Macros indicating the bearer technology */
#define XA_DTV_BEARER_TECHNOLOGY_BROADCAST ((XAuint32) 0x00000000)
#define XA_DTV_BEARER_TECHNOLOGY_UNICAST   ((XAuint32) 0x00000001)
#define XA_DTV_BEARER_TECHNOLOGY_MULTICAST ((XAuint32) 0x00000002)
#define XA_DTV_BEARER_TECHNOLOGY_LOCAL     ((XAuint32) 0x00000003)

  /* Macros indicating the bearer technology type */
#define XA_DTV_BEARER_TYPE_TERRESTRIAL        ((XAuint32) 0x00000000)
#define XA_DTV_BEARER_TYPE_CABLE              ((XAuint32) 0x00000001)
#define XA_DTV_BEARER_TYPE_HANDHELD           ((XAuint32) 0x00000002)
#define XA_DTV_BEARER_TYPE_SATELLITE          ((XAuint32) 0x00000003)
#define XA_DTV_BEARER_TYPE_SATELLITE_HANDHELD ((XAuint32) 0x00000004)
#define XA_DTV_BEARER_TYPE_INTERNET           ((XAuint32) 0x00000005)
#define XA_DTV_BEARER_TYPE_FILE               ((XAuint32) 0x00000006)

  /* Macros indicating the bearer power state */
#define XA_DTV_BEARER_STATE_ON   ((XAuint32) 0x00000002)
#define XA_DTV_BEARER_STATE_OFF  ((XAuint32) 0x00000000)
#define XA_DTV_BEARER_STATE_IDLE ((XAuint32) 0x00000001)

  /* Macros defining the reason for bearer change */
#define XA_DTV_SOURCE_BEARER_CHANGE_ADDED   ((XAuint32) 0x00000001)
#define XA_DTV_SOURCE_BEARER_CHANGE_REMOVED ((XAuint32) 0x00000002)
#define XA_DTV_SOURCE_BEARER_CHANGE_STATE   ((XAuint32) 0x00000003)

typedef struct XADTVInternetConnectionInfo_ {
    XAchar connectionName[256];
    void * pInternetConnection;
} XADTVInternetConnectionInfo;

typedef struct XADTVSourceBearerInfo_ {
    XAuint32  bearerId;
    XAchar    bearerName[256];
    XAuint32  bearerTechnology;
    XAuint32  bearerFamily;
    XAuint32  bearerType;
    XAuint32  bearerVersion;
    XAboolean bearerLocked;
} XADTVSourceBearerInfo;

XA_API extern const XAInterfaceID XA_IID_DTVSOURCEUTILITIES;

struct XADTVSourceUtilitiesItf_;
typedef const struct XADTVSourceUtilitiesItf_ * const * XADTVSourceUtilitiesItf;

typedef void (XAAPIENTRY * xaDTVSourceBearerChangeCallback) (
    XADTVSourceUtilitiesItf Caller,
    XAuint32 bearerID,
    XAuint32 changeType,
    void * pContext
);

struct XADTVSourceUtilitiesItf_ {
    XAresult (*GetNumberAvailableStaticBearers) (
        XADTVSourceUtilitiesItf self,
        XAuint32 * pNumberOfStaticBearers,
        XAuint32 * pBearerIDs
    );
    XAresult (*GetBearerInformation) (
        XADTVSourceUtilitiesItf self,
        XAuint32 bearerID,
        XADTVSourceBearerInfo * pBearerInformation
    );
    XAresult (*SetBearerState) (
        XADTVSourceUtilitiesItf self,
        XAuint32 bearerID,
        XAuint32 powerState
    );
    XAresult (*GetSignalStrength) (
        XADTVSourceUtilitiesItf self,
        XAuint32 bearerID,
        XApermille SignalStrength
    );
    XAresult (*GetNetworkTime) (
        XADTVSourceUtilitiesItf self,
        XAuint32 bearerID,
        XAtime * pTime
    );
    XAresult (*GetBearerState) (
        XADTVSourceUtilitiesItf self,
        XAuint32 bearerID,
        XAuint32 powerState
    );
    XAresult (*QueryInternetConnections) (
        XADTVSourceUtilitiesItf self,
        XAuint32 * pNumberOfInternetConnections,
        XADTVInternetConnectionInfo * pInternetConnections
    );
    XAresult (*RegisterBearerChangeCallback) (
        XADTVSourceUtilitiesItf self,
        xaDTVSourceBearerChangeCallback Callback,
        void * pContext
    );
};

/* Needed extra structures. */

typedef struct XADataLocator_DTVService_ {
    XAuint32    locatorType;
    XAObjectItf device;
} XADataLocator_DTVService;


#ifdef __cplusplus
} /* extern "C" */
#endif

#endif /* _OPENMAXALDTVEXTENSION_H_ */

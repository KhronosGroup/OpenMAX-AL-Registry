/*
 * Copyright (c) 2007-2010 The Khronos Group Inc.
 *
 * Permission is hereby granted, free of charge, to any person obtaining
 * a copy of this software and/or associated documentation files (the
 * "Materials "), to deal in the Materials without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sublicense, and/or sell copies of the Materials, and to
 * permit persons to whom the Materials are furnished to do so, subject to
 * the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Materials.
 *
 * THE MATERIALS ARE PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
 * CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
 * TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 * MATERIALS OR THE USE OR OTHER DEALINGS IN THE MATERIALS.
 *
 * OpenMAXALDTVExtension_IID.c - OpenMAX AL - Digital TV Extension
 *
 */

/****************************************************************************/
/* NOTE: This file is a standard OpenMAX AL DTV Extension file and should   */
/* not be modified in any way.                                              */
/****************************************************************************/

#include "OpenMAXALDTVExtension.h"

/*****************************************************************************/
/* Interface IDs                                                             */
/*****************************************************************************/

static const struct XAInterfaceID_ XA_IID_DTVCONTENTPROTECTION_      = { 0xcdae0f20, 0xba50, 0x11de, 0x8a39, { 0x08, 0x00, 0x20, 0x0c, 0x9a, 0x66 } };
XA_API const XAInterfaceID XA_IID_DTVCONTENTPROTECTION = &XA_IID_DTVCONTENTPROTECTION_;

static const struct XAInterfaceID_ XA_IID_DTVPLAYERTIMEDOBJECTS_     = { 0x5ab54890, 0xc463, 0x11de, 0x8a39, { 0x08, 0x00, 0x20, 0x0c, 0x9a, 0x66 } };
XA_API const XAInterfaceID XA_IID_DTVPLAYERTIMEDOBJECTS = &XA_IID_DTVPLAYERTIMEDOBJECTS_;

static const struct XAInterfaceID_ XA_IID_DTVPLAYERTIMESHIFTCONTROL_ = { 0x6822a180, 0xc463, 0x11de, 0x8a39, { 0x08, 0x00, 0x20, 0x0c, 0x9a, 0x66 } };
XA_API const XAInterfaceID XA_IID_DTVPLAYERTIMESHIFTCONTROL = &XA_IID_DTVPLAYERTIMESHIFTCONTROL_;

static const struct XAInterfaceID_ XA_IID_DTVPROGRAMGUIDEPURCHASE_   = { 0x4f664a20, 0xba4f, 0x11de, 0x8a39, { 0x08, 0x00, 0x20, 0x0c, 0x9a, 0x66 } };
XA_API const XAInterfaceID XA_IID_DTVPROGRAMGUIDEPURCHASE = &XA_IID_DTVPROGRAMGUIDEPURCHASE_;

static const struct XAInterfaceID_ XA_IID_DTVPROGRAMGUIDEQUERY_      = { 0x5cbd85b0, 0xaf5c, 0x11de, 0x8a39, { 0x08, 0x00, 0x20, 0x0c, 0x9a, 0x66 } };
XA_API const XAInterfaceID XA_IID_DTVPROGRAMGUIDEQUERY = &XA_IID_DTVPROGRAMGUIDEQUERY_;

static const struct XAInterfaceID_ XA_IID_DTVPROGRAMGUIDEUPDATE_     = { 0xe00aa3f0, 0xba4f, 0x11de, 0x8a39, { 0x08, 0x00, 0x20, 0x0c, 0x9a, 0x66 } };
XA_API const XAInterfaceID XA_IID_DTVPROGRAMGUIDEUPDATE = &XA_IID_DTVPROGRAMGUIDEUPDATE_;

static const struct XAInterfaceID_ XA_IID_DTVRECORDERMODE_           = { 0x7fac2c90, 0xc463, 0x11de, 0x8a39, { 0x08, 0x00, 0x20, 0x0c, 0x9a, 0x66 } };
XA_API const XAInterfaceID XA_IID_DTVRECORDERMODE = &XA_IID_DTVRECORDERMODE_;

static const struct XAInterfaceID_ XA_IID_DTVSERVICEDATADELIVERY_    = { 0x4d04cc20, 0xc463, 0x11de, 0x8a39, { 0x08, 0x00, 0x20, 0x0c, 0x9a, 0x66 } };
XA_API const XAInterfaceID XA_IID_DTVSERVICEDATADELIVERY = &XA_IID_DTVSERVICEDATADELIVERY_;

static const struct XAInterfaceID_ XA_IID_DTVSERVICEINPUTSELECTOR_   = { 0xa29b99b0, 0xba50, 0x11de, 0x8a39, { 0x08, 0x00, 0x20, 0x0c, 0x9a, 0x66 } };
XA_API const XAInterfaceID XA_IID_DTVSERVICEINPUTSELECTOR = &XA_IID_DTVSERVICEINPUTSELECTOR_;

static const struct XAInterfaceID_ XA_IID_DTVSOURCEBROADCAST_        = { 0x213f8170, 0xc463, 0x11de, 0x8a39, { 0x08, 0x00, 0x20, 0x0c, 0x9a, 0x66 } };
XA_API const XAInterfaceID XA_IID_DTVSOURCEBROADCAST = &XA_IID_DTVSOURCEBROADCAST_;

static const struct XAInterfaceID_ XA_IID_DTVSOURCEBROADCAST_        = { 0x36f7ca67, 0x38bd, 0x4db2, 0x811d, { 0xbf, 0x06, 0x3b, 0x54, 0x3f, 0x36 } };
XA_API const XAInterfaceID XA_IID_DTVSOURCEBROADCAST = &XA_IID_DTVSOURCEBROADCAST_;

static const struct XAInterfaceID_ XA_IID_DTVSOURCEMULTICAST_        = { 0x69558c98, 0xcea5, 0x48e7, 0x88df, { 0x6b, 0xc1, 0xb1, 0x2c, 0xde, 0x52 } };
XA_API const XAInterfaceID XA_IID_DTVSOURCEMULTICAST = &XA_IID_DTVSOURCEMULTICAST_;

static const struct XAInterfaceID_ XA_IID_DTVSOURCEUNICAST_          = { 0xe89cabec, 0x9007, 0x433b, 0x9a57, { 0x4d, 0xb4, 0xad, 0xe0, 0x4e, 0xd3 } };
XA_API const XAInterfaceID XA_IID_DTVSOURCEUNICAST = &XA_IID_DTVSOURCEUNICAST_;

static const struct XAInterfaceID_ XA_IID_DTVSOURCEUTILITIES_        = { 0x362515a0, 0xc463, 0x11de, 0x8a39, { 0x08, 0x00, 0x20, 0x0c, 0x9a, 0x66 } };
XA_API const XAInterfaceID XA_IID_DTVSOURCEUTILITIES = &XA_IID_DTVSOURCEUTILITIES_;
